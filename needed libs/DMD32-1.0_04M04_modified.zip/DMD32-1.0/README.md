# DMD32
A library for driving the Freetronics 512 pixel dot matrix LED display "DMD", a 32 x 16 layout using ESP32.

This library is a fork of the original one [(DMD)](https://github.com/freetronics/DMD) modified to support ESP32 (currently it is only working on ESP32).

The connection between ESP32 and DMD display shown in the image below:






![](https://github.com/Qudor-Engineer/DMD32/blob/main/connection.png)



I changed the SPI to VSPI and used ESP32 hardware timer and more miner modifications.

Khudhur Alfarhan 
Qudoren@gmail.com
